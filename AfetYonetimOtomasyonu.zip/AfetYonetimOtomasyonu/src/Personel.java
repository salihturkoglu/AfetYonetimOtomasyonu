
public class Personel {
    
    private int Id;
    private String Ad;
    private String Soyad;
    private String Departman;
    private String Maaş;
    
    
    public Personel(int Id, String Ad, String Soyad, String Departman, String Maaş) {
        this.Id = Id;
        this.Ad = Ad;
        this.Soyad = Soyad;
        this.Departman = Departman;
        this.Maaş = Maaş;
    }
    

    public int getId() {
        return Id;
    }

    public void setId(int Id) {
        this.Id = Id;
    }

    public String getAd() {
        return Ad;
    }

    public void setAd(String Ad) {
        this.Ad = Ad;
    }

    public String getSoyad() {
        return Soyad;
    }

    public void setSoyad(String Soyad) {
        this.Soyad = Soyad;
    }

    public String getDepartman() {
        return Departman;
    }

    public void setDepartman(String Departman) {
        this.Departman = Departman;
    }

    public String getMaaş() {
        return Maaş;
    }

    public void setMaaş(String Maaş) {
        this.Maaş = Maaş;
    }

}
