
public class Database {
    
    public static final String kullanici_adi = "root";
    public static final String parola = "root";
    public static final String db_ismi = "AYOT";
    public static final String host = "localhost";
    public static final int  port = 8889;
    
}
